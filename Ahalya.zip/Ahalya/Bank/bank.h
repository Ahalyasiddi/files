#ifndef __BANK_H_
#define __BANK_H_

#include <iostream>

using namespace std;
class Account {
private:
       string m_accName;
       string m_accNumber;
       double m_balance;

public:
  Account();
  Account(std::string, std::string, double);
  Account(std::string, std::string); 
  Account(const Account &);
  void credit(double);
  void debit(double);
  double getBalance() const;
  void display() const;
};

#endif
