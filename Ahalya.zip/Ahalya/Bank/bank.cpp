
     #include<iostream>
    #include "bank.h"


Account :: Account() :
  m_accName(), m_accNumber(), m_balance(0.0) {


}
Account :: Account(std::string accNumber, std::string accName, double m_balance) :
  m_accNumber(accNumber), m_accName(accName), m_balance(m_balance) {

}
//bank :: Account(std::string, std::string): 
Account :: Account(const Account& ref) :
        m_accName(ref.m_accName), m_accNumber(ref.m_accNumber),  
                                              m_balance(ref.m_balance) {

}
void Account::credit(double amount) {
  m_balance += amount;
}
void Account::debit(double amount) {
  //min balance check
  m_balance -= amount;
}

double Account::getBalance() const {
    return m_balance;
}
void Account :: display() const{
    std::cout <<m_accName<< "," << m_accNumber << ","
                                         << m_balance << "\n";
}