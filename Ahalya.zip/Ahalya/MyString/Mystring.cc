#include <cstring>
#include <iostream>
#include "stdint.h"
class Mystring
{
private:
    /* data */
    uint8_t len;
    char* array;

public:
    Mystring(/* args */);
    Mystring(const char*);
    Mystring(const Mystring&);
    Mystring& operator = (const Mystring&);
  
    Mystring operator +(const Mystring &ref);
    Mystring operator +(const char* q);
    Mystring operator +=(const char* q);
    bool operator == (Mystring& ref);
    bool operator > ( Mystring& ref) ;
     bool operator < ( Mystring& ref) ;
    ~Mystring();
    void display();
};

Mystring :: Mystring() :
 len(0) , array(nullptr)
{
   
}
Mystring :: Mystring(const char* ptr):
 len(strlen(ptr)) ,array(nullptr)
{
  array = new char[len + 1];
  strncpy(array, ptr,len);

}
Mystring :: Mystring(const Mystring& ref) :
    len(ref.len),array(nullptr)
{
    array = new char[len];
  strncpy(array, ref.array,len);
}

Mystring& Mystring :: operator = (const Mystring& ref)
{
    this->len = ref.len;
    strncpy(this->array, ref.array, this->len);
    return *this;
}

Mystring Mystring :: operator +(const Mystring &ref)
{
    Mystring E;
    E.len=this->len+ref.len;
    E.array = new char [E.len + 1];
    E.array = strcat(array,ref.array);
    return E;
}
Mystring Mystring :: operator +(const char* q)
{
    Mystring E;
    E.len=this->len+strlen(q);
    E.array = new char [E.len + 1];
    E.array = strcat(this->array,q);
    //std::cout<<E.array;
    return E;
}
Mystring Mystring :: operator +=(const char* q)
{
    this->len+=strlen(q);
    this->array = strcat(array,q);
    return *this;
}
 bool Mystring :: operator == (Mystring& ref)
{
     return strcmp(array,ref.array);
}
bool Mystring :: operator > ( Mystring& ref) 
{
    if(strcmp(array,ref.array)==1)
  return 1;
  else
  {
      return 0;
  }
}
 bool Mystring :: operator < ( Mystring& ref) {
    if(strcmp(array,ref.array)==-1)
  return 1;
  else
  {
      return 0;
  }
     
     
     
 }
Mystring :: ~Mystring()
{
    if (nullptr != array)
         delete[] array;
}

void Mystring :: display()
{
    std::cout << array << "\n";
}
int main()
{
  Mystring S1("Hello");
  Mystring S2("");
  Mystring S3("WELCOME");
  Mystring S4("");
  //Mystring S4 = S2;
  //S3.display();
  //S2 = S1 + "xyz";
 // S1.display();
 // S4.display();
  S4 = S1+S3;
  S4.display();
  S2 = "Welcome";
  S2.display();
  S1.display();
  S1 == S2;
  S1.display();
  S2 = S1 + "xyz";
  S2.display();
  S3 += "xyz";
  S3.display();
   
  // S1 > S2;
  // std::cout << S1 <<"/n";
  
  
  return 0;

}
