#include <iostream>
#include "stdint.h"



int main()
{
    int a = 3 ,b = 4,sum;
    sum  = a+b;
    std::cout<<sum<<std::endl;

    return 0;
}