#ifndef __SUM_H_
#define __SUM_H_
extern "C"


 int sum(int , int);
#endif