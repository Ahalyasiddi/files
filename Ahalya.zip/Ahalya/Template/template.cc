#include<iostream>
#include "stdint.h"
template<typename A>

A sum(A x,A y)
{
    A B;
    B = x + y;
    return B;
}

int main()
{
    int a , b , c;
    float x , y , z;
    double p , q , r;
    char c1,c2;
    
    c = sum(a,b);
    z = sum(x,y);
    r = sum(p,q);
    
    std::cout<<sum<float>(10.0,5.5)<<std::endl;
    std::cout<<sum<int>(10,5)<<std::endl;
    std::cout<<sum<double>(5.55,10.44)<<std::endl;
    //sum<double>
    return 0;
}