#include<iostream>
#include "stdint.h"

template<typename A>

void swap(A& n1,A& n2)
{
    A temp;
    temp = n1;
    n1 = n2;
    n2 = temp;
      
}
int main()
{
    int x = 8 , y = 9   ;
   // float x , y , z;
    //double p , q , r;
    
   // c = sum(a,b);
   // z = sum(x,y);
   // r = sum(p,q);
   swap(x,y);
  //  std::cout<<swap<int>(a,b)<<"/n";
   //std::cout<<swap<int&>(8,9)<<std::endl;
   // std::cout<<"x="<<x<<"y="<<y;
    std::cout<<"x="<<x<<"   "<<"y="<<y;
    
    //std::cout<<sum<float>(10.0,5.5)<<std::endl;
    //sum<double>
    return 0;
}